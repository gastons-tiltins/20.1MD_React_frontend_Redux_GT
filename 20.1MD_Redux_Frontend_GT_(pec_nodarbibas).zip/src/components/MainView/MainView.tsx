import {useNavigate} from 'react-router-dom';
import {Card} from '../Card/Card';
import './MainView.scss';
import {nanoid} from '@reduxjs/toolkit';

import {useSelector} from 'react-redux';
import {selectAllAnimals, removeAnimal} from '../../app/animalsSlice';
import {selectAllSpecies} from '../../app/speciesSlice';
import {useDispatch} from 'react-redux';
import {useState} from 'react';

export interface Animals {
    id: string;
    name: string;
    image: string;
    species: string;
}

export const MainView = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const animals: any = useSelector(selectAllAnimals);
    const speciesList = useSelector(selectAllSpecies);

    const [printData, setPrintData] = useState(animals);

    const handleAddAnimals = (e: any) => {
        navigate('/add');
    };

    const handleDelete = (id: string) => {
        dispatch(removeAnimal(id));
        location.reload();
    };

    return (
        <div className=''>
            {/* <div>
                {speciesList.map((specie: any) => (
                    <button
                        onClick={() => printSelectedAnimals(specie)}
                        className='button is-link is-light'
                        key={nanoid()}
                    >
                        {specie}
                    </button>
                ))}
            </div> */}
            <div>
                {printData.length <= 0 ? (
                    <div className='flexCenterColumn'>
                        <div>
                            <h1>No animals added yet</h1>
                        </div>
                        <div>
                            <button
                                className='button is-link'
                                onClick={handleAddAnimals}
                            >
                                Add animal
                            </button>
                        </div>
                    </div>
                ) : (
                    <div className='cardGrid'>
                        {animals.map((animal: Animals) => (
                            <Card
                                key={animal.id}
                                id={animal.id}
                                name={animal.name}
                                image={animal.image}
                                species={animal.species}
                                onDelete={() => handleDelete(animal.id)}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};
