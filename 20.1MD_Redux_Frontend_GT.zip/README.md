# React Redux Animal cards with filtering

### `npm i`

### `npm run dev`
