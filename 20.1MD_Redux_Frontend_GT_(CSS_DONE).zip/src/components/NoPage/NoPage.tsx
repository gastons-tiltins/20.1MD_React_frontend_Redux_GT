import React from 'react';

export const NoPage = () => {
    return <h1>404</h1>;
};
