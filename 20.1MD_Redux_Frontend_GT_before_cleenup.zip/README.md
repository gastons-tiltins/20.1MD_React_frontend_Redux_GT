# React Redux Animal cards with filtering
